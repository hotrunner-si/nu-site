export const navBar = {
  mainLink: '/',

  items: [
    {
      nameKey: 'nav.home',
      link: '/',
    },
    {
      nameKey: 'nav.projects',
      link: '/projects',
    }
  ],
}