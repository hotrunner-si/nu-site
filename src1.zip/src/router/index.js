import { createRouter, createWebHistory } from 'vue-router'

import HomeView from '../views/HomeView.vue'
import MapsView from '../views/MapsView.vue'
import WebsitesView from '../views/WebsitesView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),

  routes: [
    {
      path: '/',
      component: HomeView,
    },
    {
      path: '/maps',
      component: MapsView,
    },
    {
      path: '/websites',
      component: WebsitesView,
    }
  ],
})

export default router